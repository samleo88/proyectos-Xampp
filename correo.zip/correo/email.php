<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../phpmailer/PHPMailer/src/Exception.php';
require '../phpmailer/PHPMailer/src/PHPMailer.php';
require '../phpmailer/PHPMailer/src/SMTP.php';

EnviarEmail();

function EnviarEmail()
  {
  	if (isset($_POST['nombre'])&& isset($_POST['email']) &&isset($_POST['comentario'])) 
       {
       	 //mandar correo
       	$nombre = $_POST['nombre'];
       	$email = $_POST['email'];
       	$asunto = $_POST['asunto'];
       	$comentario = $_POST['comentario'];
       

        // el codigo siguiente es de la página https://github.com/PHPMailer/PHPMailer/
		$mail = new PHPMailer(true);

		try {
		    //Server settings
		    $mail->SMTPDebug = 3;//SMTP::DEBUG_SERVER;                      // Enable verbose debug output
		    $mail->isSMTP();     
		    $mail->Debugoutput = 'html';                                       // Send using SMTP
		    $mail->Host       = 'smtp.office365.com';                    // se trajo el de hotmail
		    //$mail->Host       = 'smtp.gmail.com';                        // el de gmail
		    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
		  /*
		    Funciona si no es correo seguro por ejemplo funciona con el hotmail 
		    */
		    $mail->Username   = 'alirio-osoriog@hotmail.com';                     // SMTP username
		    $mail->Password   = 'clave';                               // SMTP password
		  
		    $mail->SMTPSecure = 'tls';
		    //$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
		    $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

		    //Recipients
		    $mail->setFrom('alirio-osoriog@hotmail.com', 'Mailer'); // servidor desde el que se envía = USername
		    $mail->addAddress($email, 'Mailer');     // correo al que se enía 
		    //$mail->addAddress('ellen@example.com');               // Name is optional
		    //$mail->addReplyTo('info@example.com', 'Information');
		    //$mail->addCC('cc@example.com');
		    //$mail->addBCC('bcc@example.com');

		    // Attachments
		    //$mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
		    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

		    // Content
		    $mail->isHTML(true);                                  // Set email format to HTML
		    $mail->Subject = $asunto; //asunto
		    $mail->Body    = 'nombre: '.$nombre.'<br> email: '.$email.'<br> comentario:'.$comentario;
		    //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

		    $mail->send();
		    echo 'Message has been sent';
		} catch (Exception $e) {
		    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
		}


       }
    else
       {
       	return;
       }   
  }
?>