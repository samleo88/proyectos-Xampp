<html>

<head>
  <meta charset="utf-8">
  <meta name="author" content="AAOG" />
  <title> 
     <h1> EMAIL...........</h1>
  </title>
</head>
<body>
 
  <form  action = "email.php" method="POST" >
    <H2> Contacto</H2>
    <p>Nombre: <br>
       <input type="text" name="nombre" required>  </p>
    <p>Correo Electrónico: <br>
       <input type="email" name="email" required>  </p>
    <p>Asunto: <br>
       <input type="text" name="asunto" required>  </p>
    <p>texto correo: <br>
       <textarea name="comentario" id="" cols="20" required></textarea> </p>
    
        <p class="center"> 
           <input type=submit id=bt name="correo" value="enviar correo" >
        </p>
  </form>
</body>
</html>

</script>

